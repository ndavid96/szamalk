/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package x20171011;

/**
 *
 * @author Tanulo
 */
public class Verem_Exception extends Exception {
    
    public Verem_Exception(String hibaüzenet){
    super(hibaüzenet);
    
}
  
}

